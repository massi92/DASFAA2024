const abi = require("./abi.json");
const bytecode = require("./bytecode.json");

module.exports = {
  abi,
  bytecode,
};
